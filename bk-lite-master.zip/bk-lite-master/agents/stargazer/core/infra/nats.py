# -- coding: utf-8 --
# @File: nats.py
# @Time: 2025/10/20
# @Author: Optimized
"""
NATS 统一模块 - 简洁高效的 NATS 集成

提供两种使用方式：
1. 独立客户端：用于命令行工具和脚本
2. Sanic 集成：用于 Web 服务
"""

import asyncio
import json
import os
import ssl
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional

from nats.aio.client import Client as _NATSClient
from sanic import Sanic
from sanic.log import logger

# ==================== 配置类 ====================


class NATS(_NATSClient):
    """隔离上游晚到 PONG 对已取消 flush Future 的状态错误。"""

    async def _process_pong(self) -> None:
        if self._pongs:
            future = self._pongs.pop(0)
            if not future.done():
                future.set_result(True)
            self._pongs_received += 1
            self._pings_outstanding = 0


@dataclass
class NATSConfig:
    """NATS 配置（统一管理所有配置项）"""

    servers: List[str] = field(default_factory=lambda: ["nats://localhost:4222"])
    name: str = "nats-client"
    connect_timeout: int = 10  # 增加到10秒
    max_reconnect_attempts: int = 5
    reconnect_time_wait: int = 2
    pending_size: int = 2 * 1024 * 1024

    # 新增：ping 间隔和最大未响应 ping 数
    ping_interval: int = 60
    max_outstanding_pings: int = 2

    # 认证配置
    user: Optional[str] = None
    password: Optional[str] = None

    # TLS 配置
    tls_enabled: bool = False
    tls_insecure: bool = False
    tls_ca_file: Optional[str] = None
    tls_cert_file: Optional[str] = None
    tls_key_file: Optional[str] = None
    tls_hostname: Optional[str] = None

    def __post_init__(self) -> None:
        if self.pending_size <= 0:
            raise ValueError("NATS_PENDING_SIZE_BYTES must be greater than zero")
        if self.max_reconnect_attempts == 0 or self.max_reconnect_attempts < -1:
            raise ValueError("NATS_MAX_RECONNECT_ATTEMPTS must be -1 or a positive integer")

    @classmethod
    def from_env(cls, service_name: str = "nats-client") -> "NATSConfig":
        """从环境变量加载配置"""
        import re

        nats_urls = os.getenv("NATS_URLS", "nats://localhost:4222")
        servers_list = [url.strip() for url in nats_urls.split(",")]

        # 解析第一个 URL，提取用户名密码和清理后的 server 地址
        user = None
        password = None
        cleaned_servers = []

        for url in servers_list:
            # 匹配格式: protocol://user:pass@host:port 或 protocol://host:port
            match = re.match(r"^(.*?://)(?:([^:]+):([^@]+)@)?(.+)$", url)
            if match:
                protocol, url_user, url_pass, host_port = match.groups()

                # 提取用户名密码（只从第一个 URL 提取）
                if url_user and url_pass and not user:
                    user = url_user
                    password = url_pass

                # 重新构建不包含用户名密码的 URL
                cleaned_url = f"{protocol}{host_port}"
                cleaned_servers.append(cleaned_url)
            else:
                cleaned_servers.append(url)

        explicit_user = os.getenv("NATS_USERNAME")
        explicit_password = os.getenv("NATS_PASSWORD")
        if explicit_user is not None:
            user = explicit_user.strip() or None
        if explicit_password is not None:
            password = explicit_password or None

        logger.info(
            "event=nats_config_loaded servers=%s authentication_configured=%s",
            cleaned_servers,
            bool(user or password),
        )

        return cls(
            servers=cleaned_servers,
            name=service_name,
            user=user,
            password=password,
            connect_timeout=int(os.getenv("NATS_CONNECT_TIMEOUT", "10")),  # 增加到10秒
            max_reconnect_attempts=int(os.getenv("NATS_MAX_RECONNECT_ATTEMPTS", "-1")),
            reconnect_time_wait=int(os.getenv("NATS_RECONNECT_TIME_WAIT", "2")),
            pending_size=int(os.getenv("NATS_PENDING_SIZE_BYTES", str(2 * 1024 * 1024))),
            ping_interval=int(os.getenv("NATS_PING_INTERVAL", "60")),
            max_outstanding_pings=int(os.getenv("NATS_MAX_OUTSTANDING_PINGS", "2")),
            tls_enabled=os.getenv("NATS_TLS_ENABLED", "false").lower() == "true",
            tls_insecure=os.getenv("NATS_TLS_INSECURE", "false").lower() == "true",
            tls_ca_file=os.getenv("NATS_TLS_CA_FILE"),
            tls_cert_file=os.getenv("NATS_TLS_CERT_FILE"),
            tls_key_file=os.getenv("NATS_TLS_KEY_FILE"),
            tls_hostname=os.getenv("NATS_TLS_HOSTNAME"),
        )

    def create_ssl_context(self) -> Optional[ssl.SSLContext]:
        """创建 SSL 上下文"""
        if not self.tls_enabled:
            return None

        logger.info("TLS is enabled for NATS connection")
        tls_context = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH)

        if self.tls_insecure:
            logger.warning("TLS certificate verification is disabled (insecure mode)")
            tls_context.check_hostname = False
            tls_context.verify_mode = ssl.CERT_NONE
            return tls_context

        if self.tls_ca_file and os.path.exists(self.tls_ca_file):
            logger.info(f"Loading CA certificate: {self.tls_ca_file}")
            tls_context.load_verify_locations(cafile=self.tls_ca_file)

        if self.tls_cert_file and self.tls_key_file:
            if os.path.exists(self.tls_cert_file) and os.path.exists(self.tls_key_file):
                logger.info(f"Loading client certificate: {self.tls_cert_file}")
                tls_context.load_cert_chain(certfile=self.tls_cert_file, keyfile=self.tls_key_file)

        return tls_context

    def to_connect_options(self) -> dict:
        """转换为 NATS 连接选项"""
        options = {
            "servers": self.servers,
            "name": self.name,
            "connect_timeout": self.connect_timeout,
            "max_reconnect_attempts": self.max_reconnect_attempts,
            "reconnect_time_wait": self.reconnect_time_wait,
            "ping_interval": self.ping_interval,
            "max_outstanding_pings": self.max_outstanding_pings,
            "pending_size": self.pending_size,
        }

        # 添加认证信息
        if self.user:
            options["user"] = self.user
        if self.password:
            options["password"] = self.password

        # 添加 TLS 配置
        tls_context = self.create_ssl_context()
        if tls_context:
            options["tls"] = tls_context
            if self.tls_hostname:
                options["tls_hostname"] = self.tls_hostname

        return options


# ==================== 独立客户端 ====================


class NATSClient:
    """
    独立的 NATS 客户端
    用于命令行工具、脚本等场景
    """

    def __init__(self, config: Optional[NATSConfig] = None):
        self.config = config or NATSConfig.from_env()
        self.nc: Optional[NATS] = None

    async def connect(self) -> None:
        """连接到 NATS 服务器"""
        if self.nc and not self.nc.is_closed:
            logger.info("NATS already connected, reusing existing connection")
            return

        try:
            logger.info(f"[NATSClient] Connecting to NATS servers: {self.config.servers}")
            logger.info(f"[NATSClient] Connection timeout: {self.config.connect_timeout}s")
            logger.info(f"[NATSClient] TLS enabled: {self.config.tls_enabled}")
            logger.info("[NATSClient] Authentication configured: " f"{bool(self.config.user or self.config.password)}")

            # 尝试DNS解析检查
            try:
                import socket

                for server in self.config.servers:
                    # 从URL中提取主机名和端口
                    if "://" in server:
                        host_part = server.split("://")[1]
                        if ":" in host_part:
                            host = host_part.split(":")[0]
                        else:
                            host = host_part

                        logger.info(f"[NATSClient] Resolving DNS for {host}...")
                        ip = socket.gethostbyname(host)
                        logger.info(f"[NATSClient] DNS resolved: {host} -> {ip}")
            except Exception as dns_err:
                logger.warning(f"[NATSClient] DNS resolution check failed: {dns_err}")

            connect_options = self.config.to_connect_options()
            logger.info(
                f"[NATSClient] Connect options: timeout={connect_options.get('connect_timeout')}s, "
                f"max_reconnect_attempts={connect_options.get('max_reconnect_attempts')}, "
                f"reconnect_wait={connect_options.get('reconnect_time_wait')}s"
            )

            # 创建 NATS 实例并连接
            self.nc = NATS()

            # 使用 asyncio.wait_for 添加额外的超时保护
            try:
                await asyncio.wait_for(
                    self.nc.connect(**connect_options),
                    timeout=self.config.connect_timeout + 5,  # 额外5秒缓冲
                )
            except asyncio.TimeoutError:
                logger.error(f"[NATSClient] Connection timeout after {self.config.connect_timeout + 5}s")
                raise ConnectionError(f"NATS connection timeout to {self.config.servers}")

            if self.nc.is_connected:
                logger.info(f"[NATSClient] ✓ Successfully connected to NATS: {self.config.servers}")
                logger.info(f"[NATSClient] Connection status - is_connected: {self.nc.is_connected}, is_closed: {self.nc.is_closed}")
            else:
                logger.error("[NATSClient] Connection failed - not connected!")
                raise ConnectionError("NATS connection failed")

        except asyncio.TimeoutError as te:
            logger.error(f"[NATSClient] Connection timeout: {te}")
            logger.error("[NATSClient] This usually means:")
            logger.error("[NATSClient]   1. NATS server is not reachable (network issue)")
            logger.error(f"[NATSClient]   2. NATS server is not running on {self.config.servers}")
            logger.error("[NATSClient]   3. Firewall is blocking the connection")
            logger.error("[NATSClient]   4. DNS resolution failed")
            self.nc = None
            raise ConnectionError(f"NATS connection timeout to {self.config.servers}")
        except Exception as e:
            logger.error(f"[NATSClient] Failed to connect to NATS: {e}")
            logger.error(f"[NATSClient] Connection details - servers: {self.config.servers}, tls: {self.config.tls_enabled}")
            import traceback

            logger.error(f"[NATSClient] Traceback: {traceback.format_exc()}")
            self.nc = None  # 确保 nc 为 None
            raise  # 重新抛出异常，让调用者知道连接失败了

    async def request(self, subject: str, data: Any, timeout: float = 60.0) -> Any:
        """发送请求并等待响应"""
        if not self.nc or self.nc.is_closed:
            raise ConnectionError("Not connected to NATS")

        payload = json.dumps(data).encode()
        response = await self.nc.request(subject, payload=payload, timeout=timeout)
        return json.loads(response.data.decode())

    async def publish(self, subject: str, data: Any) -> None:
        """发布消息"""
        if not self.nc or self.nc.is_closed:
            raise ConnectionError("Not connected to NATS")

        payload = json.dumps(data).encode()
        await self.nc.publish(subject, payload)

    async def close(self) -> None:
        """关闭连接"""
        if self.nc and not self.nc.is_closed:
            await self.nc.drain()

    @property
    def is_connected(self) -> bool:
        return self.nc is not None and not self.nc.is_closed

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


# ==================== Sanic 集成 ====================


class NATSSanic:
    """
    Sanic 框架的 NATS 集成
    自动管理连接生命周期，支持消息订阅和处理
    """

    def __init__(self, app: Sanic, service_name: str, config: Optional[NATSConfig] = None):
        self.app = app
        self.service_name = service_name
        self.config = config or NATSConfig.from_env(service_name)
        self.nc = NATS()
        self.handlers: Dict[str, Callable] = {}
        self._pending_handlers: List[tuple] = []
        self._is_connecting = False
        self._shutting_down = False

        self._register_lifecycle()

    def _register_lifecycle(self):
        """注册 Sanic 生命周期事件"""

        @self.app.listener("before_server_start")
        async def start_nats(app, loop):
            await self._connect()
            await self._register_pending_handlers()

        @self.app.listener("after_server_stop")
        async def stop_nats(app, loop):
            await self._disconnect()

    async def _connect(self):
        """连接到 NATS"""
        if self._is_connecting:
            return

        self._is_connecting = True
        try:
            options = self.config.to_connect_options()
            options.update(
                {
                    "closed_cb": self._on_closed,
                    "disconnected_cb": self._on_disconnected,
                    "reconnected_cb": self._on_reconnected,
                    "error_cb": self._on_error,
                }
            )

            await self.nc.connect(**options)
            self.app.ctx.nats_connected = True
            self.app.ctx.nats = self
            logger.info(f"NATS service '{self.service_name}' started")
        except Exception as e:
            logger.error(f"Failed to connect NATS: {e}")
            self.app.ctx.nats_connected = False
            raise
        finally:
            self._is_connecting = False

    async def _disconnect(self):
        """断开连接"""
        if self._shutting_down or self.nc.is_closed:
            return

        self._shutting_down = True
        try:
            await self.nc.drain()
            logger.info("NATS service stopped")
        except Exception as e:
            logger.error(f"Error stopping NATS: {e}")
        finally:
            self.app.ctx.nats_connected = False

    async def _on_closed(self):
        if not self._shutting_down:
            logger.warning("event=nats_connection_closed channel=subscriber")
            self.app.ctx.nats_connected = False

    async def _on_disconnected(self):
        logger.warning("event=nats_connection_disconnected channel=subscriber")
        self.app.ctx.nats_connected = False

    async def _on_reconnected(self):
        logger.info("event=nats_connection_reconnected channel=subscriber")
        self.app.ctx.nats_connected = True

    async def _on_error(self, e):
        logger.error(
            "event=nats_connection_error channel=subscriber error_type=%s",
            type(e).__name__,
        )

    async def _register_pending_handlers(self):
        """注册所有待处理的消息处理器"""
        for subject, handler, queue in self._pending_handlers:
            await self.subscribe(subject, handler, queue)
        self._pending_handlers.clear()

    def register_handler(self, subject: str, queue: Optional[str] = None):
        """装饰器：注册消息处理器"""

        def decorator(handler: Callable[[dict], Awaitable[dict]]):
            self._pending_handlers.append((subject, handler, queue))
            return handler

        return decorator

    async def subscribe(self, subject: str, handler: Callable, queue: Optional[str] = None):
        """订阅主题"""
        full_subject = f"{self.service_name}.{subject}"

        async def message_handler(msg):
            try:
                data = json.loads(msg.data.decode()) if msg.data else {}
                result = await handler(data)

                if msg.reply:
                    response = {"success": True, **result}
                    await self.nc.publish(msg.reply, json.dumps(response).encode())
            except Exception as e:
                logger.error(f"Error processing {msg.subject}: {e}", exc_info=True)
                if msg.reply:
                    error_response = {"success": False, "error": str(e)}
                    await self.nc.publish(msg.reply, json.dumps(error_response).encode())

        await self.nc.subscribe(full_subject, queue=queue, cb=message_handler)
        self.handlers[subject] = handler
        logger.info(f"Subscribed to '{full_subject}'")

    async def publish(self, subject: str, data: Any):
        """发布消息"""
        if self.nc.is_closed:
            raise ConnectionError("NATS not connected")
        await self.nc.publish(subject, json.dumps(data).encode())

    async def request(self, subject: str, data: Any, timeout: float = 5.0) -> Any:
        """发送请求并等待响应"""
        if self.nc.is_closed:
            raise ConnectionError("NATS not connected")

        payload = json.dumps(data).encode()
        msg = await self.nc.request(subject, payload, timeout=timeout)
        return json.loads(msg.data.decode())

    @property
    def is_connected(self) -> bool:
        return not self.nc.is_closed and getattr(self.app.ctx, "nats_connected", False)


# ==================== 全局管理器（便捷接口）====================

_nats_instance: Optional[NATSSanic] = None


def initialize_nats(app: Sanic, service_name: str) -> NATSSanic:
    global _nats_instance
    _nats_instance = NATSSanic(app, service_name)
    logger.info(f"NATS initialized with service_name: {service_name}")
    return _nats_instance


def register_handler(subject: str, queue: Optional[str] = None):
    """装饰器：注册消息处理器"""
    if _nats_instance is None:
        raise RuntimeError("NATS not initialized. Call initialize_nats() first.")
    return _nats_instance.register_handler(subject, queue)


def get_nats() -> NATSSanic:
    """获取 NATS 实例"""
    if _nats_instance is None:
        raise RuntimeError("NATS not initialized. Call initialize_nats() first.")
    return _nats_instance


def subscriber_transport_ready() -> bool:
    """订阅连接必须已连接；重连中不能接收新的请求。"""

    instance = _nats_instance
    if instance is None:
        return False
    return bool(instance.nc.is_connected and not bool(getattr(instance.nc, "is_reconnecting", False)))
